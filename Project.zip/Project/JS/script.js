function ChackLogin () {
    let log =  localStorage.getItem('login') || "0";
   IsLogin = log == "1"? true:false;
}

function logout () {
   localStorage.setItem('login',"0");
   ClickSide('login.html');
   alert("تم تسجيل الخروج");
    
}
function ClickSide(site)
{
//    ChackLogin();
// //   alert('asdad');

//     if(site == 'Register2.html' || site == 'login.html')
//     {
//         let ifram = parent.document.getElementById('frm5');
//     ifram.src = site;
//     }
    // else  
    //     {
    
    
         let ifram2 = parent.document.getElementById('frm5');
         ifram2.src = site;
        //    if (!IsLogin) return;
                
                
        //     }  
        }
        function GetUsers () {
            usrs = JSON.parse(localStorage.getItem('users')) || [];
            
        }
        function decrement()
        {
    let dec = document.getElementById('qty');
    if (Number. parseInt(dec.textContent) > 1) {
        
        dec.textContent = Number. parseInt(dec.textContent) - 1;
    }

}
let table = [[]];
let tab = [[]];
function AddItem (product,qty,price) {
      let t = document.getElementById('tabcart');
    let tr = document.createElement('tr');
    let td1 = document.createElement('td');
    td1.textContent = product;
    let td2 = document.createElement('td');
    td2.textContent = qty;
    let td3 = document.createElement('td');
    td3.textContent = price;
    
    t.appendChild(tr);
    tr.appendChild(td1);
    tr.appendChild(td2);
    tr.appendChild(td3);
}
function AddItems (product,qty,price) {
   
      let t = document.getElementById('tabcarts');
    let tr = document.createElement('tr');
    let td1 = document.createElement('td');
    td1.textContent = product;
    let td2 = document.createElement('td');
    td2.textContent = qty;
    let td3 = document.createElement('td');
    td3.textContent = price;
    
    t.appendChild(tr);
    tr.appendChild(td1);
    tr.appendChild(td2);
    tr.appendChild(td3);
}
function GetRecClients () {
    
    let c = 0;
   recs = JSON.parse(localStorage.getItem('request')) || [];
for (let i = 0; i < recs.length; i++) {
    AddRec(recs[i][0],recs[i][1],recs[i][2]);
   // alert(recs[i][0] + ' ' + recs[i][1]+ '  ' +recs[i][2]);
    c ++;
    
}
let count = document.getElementById('count');
count.textContent = c.toString();

}
function AddRec (username,title,description) {
 //   alert(username + ' ' + title + ' ' + description);
      let t = document.getElementById('tabr');
    let tr = document.createElement('tr');
    let td1 = document.createElement('td');
    td1.textContent = username;
    let td2 = document.createElement('td');
    td2.textContent = title;
    let td3 = document.createElement('td');
    td3.textContent = description;
    
    t.appendChild(tr);
    tr.appendChild(td1);
    tr.appendChild(td2);
    tr.appendChild(td3);
}
let recs = [];
function AddToRec () {
    
    // alert(1);
   recs = JSON.parse(localStorage.getItem('request')) || [];

   // let add = document.getElementById('add');
    let username = localStorage.getItem('username');
    let title = document.getElementById('titl');
    let description = document.getElementById('desc');
   //  alert(username );
    recs.push([username,title.value,description.value]);
localStorage.setItem('request',JSON.stringify(recs));
}
function AddToCart () {
    
    // alert(1);
   table = JSON.parse(localStorage.getItem('table')) || [];

    let add = document.getElementById('add');
    let product = document.getElementById('product');
    let qty = document.getElementById('qty');
    let price = document.getElementById('price');
    let username = localStorage.getItem('username');
    table.push([product.textContent,qty.textContent,(Number.parseInt(price.textContent)*Number.parseInt(qty.textContent)),username]);
localStorage.setItem('table',JSON.stringify(table));
//     if (table.length == 0) {
//     }
//     else
//     {
//     for (let i = 0; i < table.length; i++) {
       
        
//         if (table[i][0] == product) {
//             table[i][1] = table[i][1]+Number.parseInt(qty.textContent);
//             table[i][2] = table[i][2]+(Number.parseInt(price.textContent)*Number.parseInt(qty.textContent));
//            localStorage.setItem('table',JSON.stringify(table));
//            break;

//            //    add.click();
//         }
//         else{
//             // alert(2);
//  table.push([product.textContent,qty.textContent,(Number.parseInt(price.textContent)*Number.parseInt(qty.textContent))]);
//     localStorage.setItem('table',JSON.stringify(table));
// }
// }
// }
// add.click();
   
        ClickSide('cart.html');
// alert(t);


}
function GetAllTable () {
    let T = 0;
    // let username = localStorage.getItem('username');
   tab = JSON.parse(localStorage.getItem('table')) || [];
for (let i = 0; i < tab.length; i++) {
    
        
    
    AddItems(tab[i][0],tab[i][1],tab[i][2]);
    T +=  Number.parseInt(tab[i][2]);
    
    
}
let total = document.getElementById('tot');
total.textContent = T.toString();
// alert(table);
}
function GetTable () {
    let T = 0;
    let username = localStorage.getItem('username');
   table = JSON.parse(localStorage.getItem('table')) || [];
for (let i = 0; i < table.length; i++) {
    if (table[i][3] == username) {
        
    
    AddItem(table[i][0],table[i][1],table[i][2]);
    T +=  Number.parseInt(table[i][2]);
    }
    
}
let total = document.getElementById('total');
total.textContent = T.toString();
// alert(table);
}
        function increment()
        {
    let inc = document.getElementById('qty');
    inc.textContent = Number. parseInt(inc.textContent) + 1;

}
function register () {
     let username = document.getElementById('username');
   let password = document.getElementById('password');
   GetUsers();
  for (let i = 0; i < usrs.length; i++) {
    if (username.value == usrs[i][0]) {
    let s = document.getElementById('success');
       s.textContent = 'اسم المستخدم موجود بالفعل ';
       s.style.color = "red";
       s.style.fontSize = "14pt";
       return;
   }
    
  }
   usrs.push([username.value.toString(),password.value.toString()]);
   localStorage.setItem('users',JSON.stringify(usrs));
      alert('تم انشاء اسم بنجاح');
      console.log(usrs);
 let s = document.getElementById('success');
       s.textContent = 'تم انشاء اسم بنجاح';
       s.style.color = "green";
       s.style.fontSize = "14pt";
}
let usrs = [['ddy9723','alalimi123'],['koko','123']];
function h () {
    let frm = document.getElementById('frm');
    let lbl = document.getElementById('lbl');
    let doc  = frm.contentWindow.document;
    let height = doc.body.scrollHeight;
    frm.style.height = height + "px";
    lbl.textContent = "sas" +(height + "px").toString();
    lbl.title = "sas" ;
//     frm.onload = function  () {
//     let doc  = frm.contentWindow.document;
//     let height = doc.body.scrollHeight;
//     frm.style.height = height + "px";
//     lbl.textContent = "sas" +(height + "px").toString();
//     lbl.title = "sas" ;
// };

}


function Prods() {
    c = 0;
                 sec = document.getElementById('sec');
                     div = document.createElement('div');
    for (let index = 0; index < 9; index++) {
        if (c == 0) {
            
            prodata('brake-pads.png','فرامل ياباني','250');
        }
        else if (c == 1) {
            prodata('spark-plugs-wires.png','بلاكات بلاتينيوم','22');
            
        }
        else if(c == 2)
            {
                prodata('brake-drums-rotors_1.webp','صحون فرامل','90');
                
            }
            else (c== 3)
            {
                prodata('engine-air-filter.webp','فلتر هواء','47');
                
            }
            if(c==4)
                {
                    
                    prodata('true-start-true-2-batteries_3.webp','فلتر هواء','47');
                    c = 0;
                }
                c++;
                
                
            }
            
            
            
        }

        //  let btn = document.getElementById('btn');
        //  btn.click();
        //  let frm = document.getElementById('frm');
        //     let lbl = document.getElementById('lbl');
        //     let doc  = frm.contentWindow.document;
        //     let height = doc.body.scrollHeight;
        //     frm.style.height = height + "px";
        //     lbl.textContent = "sas" +(height + "px").toString();
        //     lbl.title = "sas" ;
        
        
        
        
        function GetProd () {
            // alert('asdad');
            let  prod = JSON.parse(localStorage.getItem('prod')) || [];
            let img = document.getElementById('img');
            let product = document.getElementById('product');
            let qty = document.getElementById('qty');
            let price = document.getElementById('price');
            img.textContent= prod[0];
            product.textContent= prod[1];
            price.textContent= prod[2];
        }
        // <div class="products">
        // <div class="product">
        //   <img src="brake-pads.png" alt="زيت محرك">
        //   <h3>زيت محرك</h3>
        //   <p>30$</p>
        //   <a href="product.html" class="btn">تفاصيل</a>
        // </div>
        let IsLogin = false;
        function OnClick() {
            // let c = document.getElementById('Main')
            usrs = JSON.parse(localStorage.getItem('users')) || [];
                        // alert('asdsad');
            
            let username = document.getElementById('username');
            let password = document.getElementById('password');
            let isFalse = false;
            if (usrs.length == 0) {
                alert('لايوجد مستخدمين');
                return;
            }

            // alert(usrs.length);
            for (let index = 0; index < usrs.length; index++) {
                // alert('asdsad');
                        // alert('asdsad');

                        if (usrs[index][0] == username.value | password.value == usrs[index][1]) {
                        
                        isFalse = false;
                        IsLogin = true;
                        let clients =  parent.document.getElementById('clients');
                        let carts =  parent.document.getElementById('carts');
                        // btn.style.visibility = 'hidden';
                        
                        if (username.value == 'admin' ) {
                            clients.style.visibility = 'visible';
                            carts.style.visibility = 'visible';
                        }
                        else
                            clients.style.visibility = 'hidden';
                            carts.style.visibility = 'hidden';
                        
                        localStorage.setItem('login',"1");
                        localStorage.setItem('username', username.value);
                        localStorage.setItem('password', password.value);
                        
                        ClickSide('main.html');
                        
                    //    let ifram = parent.document.getElementById('frm5');
                    // ifram.src = 'main.html';
                    //    alert(usrs[index][1]);
                    
                    break;
                    
                    // window.location.href = "index.html"
                }
                else
                    IsLogin = false;
                //    alert(usrs[index][0]);
                
                isFalse = true;
                
            }
            if (isFalse) {
                //     ClickSide('main.html');
                
                //    let ifram = parent.document.getElementById('frm5');
                // ifram.src = 'main.html';
                
                //     alert('errrr');
                
                
                alert('Invalid Username/Password');
                let s = document.getElementById('success');
                s.textContent = 'Invalid Username/Password';
                s.style.color = "red";
                s.style.fontSize = "14pt";
                
            }
            // else{
                
                //      ClickSide('main.html');
                
                //    let ifram = parent.document.getElementById('frm5');
                // ifram.src = 'main.html';
                
                
                // }
                
            }
            function ClickProduct(src) {
                let content2 = document.getElementById('frm')
                content2.src = src
            }
            
            
            function ClickBar(src,id) {
                document.getElementById('about').style.setProperty("--op","0")
                document.getElementById('main').style.setProperty("--op","0")
                document.getElementById('products').style.setProperty("--op","0")
                document.getElementById('services').style.setProperty("--op","0")
                document.getElementById('cart').style.setProperty("--op","0")
                document.getElementById('contact').style.setProperty("--op","0")
                let content = document.getElementById(id)
                content.style.setProperty("--op","1")
                let content2 = document.getElementById('frm')
                content2.src = src
                // let classname = 'active'
                // // let content2 = document.getElementById(id)
                // // content2.className = classname
                // switch (id) {
                    //   case 'about':
                    //     document.getElementById('about').className = 'btn ' + classname  
                    //     document.getElementById('about').style.opacity = 1 'btn ' + classname  
                    //     document.getElementById('main').className = 'btn'  
                    //     document.getElementById('products').className = 'btn'  
                    //     document.getElementById('services').className = 'btn'  
                    //     document.getElementById('cart').className = 'btn'  
                    //     document.getElementById('contact').className = 'btn'  
                    //     break;
                    //     case 'main':
                    //       document.getElementById('main').className = 'btn ' + classname  
                    //       document.getElementById('about').className = 'btn'  
                    //       document.getElementById('products').className = 'btn'  
                    //       document.getElementById('services').className = 'btn'  
                    //       document.getElementById('cart').className = 'btn'  
                    //       document.getElementById('contact').className = 'btn'  
                    //       break;
                    //       case 'products':
                    //         document.getElementById('products').className = 'btn ' + classname  
                    //         document.getElementById('main').className = 'btn'  
                    //         document.getElementById('about').className = 'btn'  
                    //         document.getElementById('services').className = 'btn'  
                    //         document.getElementById('cart').className = 'btn'  
                    //         document.getElementById('contact').className = 'btn'  
                    //         break;
                    //         case 'services':
                    //           document.getElementById('services').className = 'btn ' + classname  
                    //           document.getElementById('main').className = 'btn'  
                    //           document.getElementById('products').className = 'btn'  
                    //           document.getElementById('about').className = 'btn'  
                    //           document.getElementById('cart').className = 'btn'  
                    //           document.getElementById('contact').className = 'btn'  
                    //           break;
                    //           case 'cart':
                    //             document.getElementById('cart').className = 'btn ' + classname  
                    //             document.getElementById('main').className = 'btn'  
                    //             document.getElementById('products').className = 'btn'  
                    //             document.getElementById('services').className = 'btn'  
                    //             document.getElementById('about').className = 'btn'  
                    //             document.getElementById('contact').className = 'btn'  
                    //             break;
                    //             case 'contact' :
                    //               document.getElementById('contact').className = 'btn ' + classname  
                    //               document.getElementById('main').className = 'btn'  
                    //               document.getElementById('products').className = 'btn'  
                    //               document.getElementById('services').className = 'btn'  
                    //               document.getElementById('cart').className = 'btn'  
                    //               document.getElementById('about').className = 'btn'  
                    //               break;
                    
                    
                    //             }
                    
                    
                }
                            let sec = document.getElementById('sec');
                    let div = document.createElement('div');
                
                function prodata (imge,name,price) {
                    //   let sec = document.getElementById('sec');
                    // let div = document.createElement('div');
                     
                 div.className = 'products mydiv1';
                
                  let div2 = document.createElement('div');
                    div2.className = 'product';
                    let img = document.createElement('img');
                    img.src = imge;
                    img.alt = 'زيت محرك';
                    let h3 = document.createElement('h3');
                    h3.textContent = name;
                    let p = document.createElement('p');
                    p.textContent = price;
                    let button = document.createElement('button');
                     button.className = 'btn';
                    button.textContent = 'تفاصيل';
                    let a = document.createElement('a');
                    a.href = 'product.html';
                    // a.className = 'btn';
                    // a.textContent = 'تفاصيل';
                    let prod = [img.src,h3.textContent,p.textContent];
                    button.onclick = function  () {
                        localStorage.setItem('prod',JSON.stringify(prod));
                        a.click();
                p.textContent = p.textContent+'$';
            };
            div.appendChild(div2);
            div2.appendChild(img);
            div2.appendChild(h3);
            div2.appendChild(p);
            div2.appendChild(button);
                    button.appendChild(a);
                    sec.appendChild(div);
                 
                }